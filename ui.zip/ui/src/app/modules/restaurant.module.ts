export interface Restaurant{
    id: string;
    restoName : string;
    location: string;
    specialities: string;
    additiionalFeatures: string;
}