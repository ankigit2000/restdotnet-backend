﻿namespace FullStack.API.Models
{
    public class Restaurant
    {
        public Guid id { get; set; }
        public string restoName { get; set;}
        public string location { get; set;}
        public string specialities { get; set;}
        public string additiionalFeatures { get; set;}
        public string menu {  get; set;}
    }
}
